#ifndef _INTERCEPT_H_
#define _INTERCEPT_H_

int intercept(int p, int v);
bool check(int L, int R);

#endif
